#ifndef CH_MEMORY_H
# define CH_MEMORY_H

/* include files */
#include <string.h>
#include <stdio.h>
#include "ch_utility.h"

/* constraints */

/* function */
void dump(int, int);
void edit(int, int);
void fill(int, int, int);
void reset();

# endif